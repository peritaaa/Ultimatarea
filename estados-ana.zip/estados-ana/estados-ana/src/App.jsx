import { useState } from 'react'
import './App.css'
import Actividad from './components/Actividad'


function App() {
  

  return (
    <div className="App">
      <Actividad 
   

   /> 
    </div>
  )
}

export default App
